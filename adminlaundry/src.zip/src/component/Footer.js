import React from 'react';
import "./Footer.css"

const Footer = () => {
    return (
        <div className="footer-container">
         <p>Made by Richard Abdul Kareem &#169;2023 </p>
        </div>
    );
}

export default Footer;
